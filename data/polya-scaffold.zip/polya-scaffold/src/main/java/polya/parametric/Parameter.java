package polya.parametric;


/**
 * See CollapsedConjugateModel
 * 
 * @author Alexandre Bouchard (alexandre.bouchard@gmail.com)
 *
 */
public interface Parameter
{

}
